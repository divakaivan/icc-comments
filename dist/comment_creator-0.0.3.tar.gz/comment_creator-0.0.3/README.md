# Comment generator

When passed a word, this piece of code transforms the text into a B I G hashtag style word.


